/*
 * WiFi Manager - Unified WiFi connection management
 * 
 * Thread Safety:
 * - All public methods are thread-safe (protected by internal mutex)
 * - Event callback is invoked from WiFi event task
 * 
 * Usage:
 *   auto& wifi = WifiManager::GetInstance();
 *   
 *   EventGroupHandle_t events = xEventGroupCreate();
 *   wifi.SetEventCallback([events](WifiEvent e) {
 *       if (e == WifiEvent::Connected) xEventGroupSetBits(events, BIT0);
 *       if (e == WifiEvent::ConfigModeExit) xEventGroupSetBits(events, BIT1);
 *   });
 *   
 *   wifi.Initialize(config);
 *   wifi.StartStation();
 *   xEventGroupWaitBits(events, BIT0 | BIT1, pdTRUE, pdFALSE, portMAX_DELAY);
 */

#ifndef _WIFI_MANAGER_H_
#define _WIFI_MANAGER_H_

#include <string>
#include <memory>
#include <functional>
#include <mutex>
#include <atomic>
#include "internet_status.h"

#include "wifi_station.h"

class WifiStation;
class WifiConfigurationAp;

// WiFi events
enum class WifiEvent {
    Scanning,          // Started scanning for networks
    Connecting,        // Connecting to network (call GetSsid() for target)
    Connected,         // Successfully connected
    Disconnected,      // Disconnected from network
    ConfigModeEnter,   // Entered config AP mode
    ConfigModeExit,    // Exited config AP mode
};

// Configuration
struct WifiManagerConfig {
    std::string ssid_prefix = "ESP32";    // AP mode SSID prefix
    // Optional exact AP name. When empty, ssid_prefix plus a MAC suffix is used.
    std::string fixed_ap_ssid;
    std::string language = "zh-CN";       // Web UI language
    
    // Station mode scan interval with exponential backoff
    int station_scan_min_interval_seconds = 10;   // Initial scan interval (fast retry)
    int station_scan_max_interval_seconds = 60;   // Maximum scan interval (1 minute)
    std::string station_hostname;                  // Optional DHCP hostname for station mode

    // How many times to retry the strongest same-SSID AP before falling back to
    // a weaker one (requires WIFI_ALL_CHANNEL_SCAN, which is the default when
    // remember_bssid is off). 0 = driver default (one attempt only).
    uint8_t station_failure_retry_cnt = 3;

    // Whether to show the OTA URL field in the config portal advanced tab.
    // Defaults to false so the field is hidden unless explicitly enabled.
    bool show_ota_config = false;

    // Whether to show the sleep mode toggle in the config portal advanced tab.
    bool show_sleep_config = false;
};

/**
 * WifiManager - Singleton for WiFi management
 */
class WifiManager {
public:
    static WifiManager& GetInstance();

    // ==================== Lifecycle ====================
    
    bool Initialize(const WifiManagerConfig& config = WifiManagerConfig{});
    bool IsInitialized() const;

    // ==================== Station Mode ====================
    
    void StartStation();   // Non-blocking, auto-stops config AP if active
    void StopStation();    // Non-blocking
    
    bool IsConnected() const;
    bool HasInternet() const { return GetInternetStatus() == InternetStatus::Online; }
    InternetStatus GetInternetStatus() const { return IsConnected() ? internet_status_.load() : InternetStatus::Offline; }
    void SetPreferredSsid(std::function<std::string()> provider);
    int LastConfigDisconnectReason() const;
    std::string GetSsid() const;
    std::string GetIpAddress() const;
    int GetRssi() const;
    int GetChannel() const;
    std::string GetMacAddress() const;

    // ==================== Config AP Mode ====================
    
    void StartConfigAp(bool external_portal = false, bool device_only = false);
    void StopConfigAp();   // Non-blocking
    
    bool IsConfigMode() const;
    std::string GetApSsid() const;
    std::string GetApWebUrl() const;

    // Device-side configuration UI support. The captive portal remains active
    // while these methods expose its scan results and verified connection flow.
    std::vector<wifi_ap_record_t> GetConfigAccessPoints();
    bool ConfigureNetwork(const std::string& ssid, const std::string& password, bool keep_ap = false);

    // ==================== Power ====================
    
    void SetPowerSaveLevel(WifiPowerSaveLevel level);

    // Key press / app open while offline: rescan without waiting for backoff.
    void ScanNow();

    // ==================== Event ====================
    
    void SetEventCallback(std::function<void(WifiEvent, const std::string&)> callback);

    const WifiManagerConfig& GetConfig() const { return config_; }

    WifiManager(const WifiManager&) = delete;
    WifiManager& operator=(const WifiManager&) = delete;

private:
    WifiManager();
    ~WifiManager();

    void NotifyEvent(WifiEvent event, const std::string& data = "");
    void CheckInternet();
    void InvalidateInternet();
    static void InternetWorker(void *arg);
    static uint32_t NetworkHash(const std::string &ssid);
    void AllowNetwork(const std::string &ssid);
    std::atomic<InternetStatus> internet_status_{InternetStatus::Offline};
    std::atomic<unsigned> network_generation_{0};
    std::atomic<bool> internet_worker_{false};
    std::atomic<uint32_t> excluded_[10]{};

    WifiManagerConfig config_;
    std::unique_ptr<WifiStation> station_;
    std::unique_ptr<WifiConfigurationAp> config_ap_;

    mutable std::mutex mutex_;
    bool initialized_ = false;
    bool station_active_ = false;
    bool config_mode_active_ = false;
    // 期望省电档:station 未运行时 SetPowerSaveLevel 只记这里,StartStation 重放。
    // 默认 BALANCED 等价 IDF 默认 MIN_MODEM,保持历史行为。
    WifiPowerSaveLevel desired_ps_level_ = WifiPowerSaveLevel::BALANCED;

    std::function<void(WifiEvent, const std::string&)> event_callback_;
    mutable std::string mac_address_;
};

#endif // _WIFI_MANAGER_H_
