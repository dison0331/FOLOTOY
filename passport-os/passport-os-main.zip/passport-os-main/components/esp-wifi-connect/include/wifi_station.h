#ifndef _WIFI_STATION_H_
#define _WIFI_STATION_H_

#include <string>
#include <vector>
#include <functional>

#include <esp_event.h>
#include <esp_timer.h>
#include <esp_netif.h>
#include <esp_wifi_types_generic.h>

// WiFi power save level enumeration
enum class WifiPowerSaveLevel {
    LOW_POWER,    // Maximum power saving (WIFI_PS_MAX_MODEM)
    BALANCED,     // Minimum power saving (WIFI_PS_MIN_MODEM)
    PERFORMANCE,  // No power saving (WIFI_PS_NONE) - full power
};

struct WifiApRecord {
    std::string ssid;
    std::string password;
    int channel;
    wifi_auth_mode_t authmode;
    uint8_t bssid[6];
    int8_t rssi;
};

/**
 * WifiStation - WiFi station mode handler
 * 
 * This class handles connecting to WiFi access points in station mode.
 * Note: WiFi driver must be initialized before using this class.
 */
class WifiStation {
public:
    WifiStation();
    ~WifiStation();

    // Delete copy constructor and assignment operator
    WifiStation(const WifiStation&) = delete;
    WifiStation& operator=(const WifiStation&) = delete;

    void AddAuth(const std::string &&ssid, const std::string &&password);
    void Start();
    void Stop();
    bool IsConnected();
    bool WaitForConnected(int timeout_ms = 10000);
    int8_t GetRssi();
    std::string GetSsid() const { return ssid_; }
    std::string GetIpAddress() const { return ip_address_; }
    uint8_t GetChannel();
    void SetPowerSaveLevel(WifiPowerSaveLevel level);

    void OnConnect(std::function<void(const std::string& ssid)> on_connect);
    void OnConnected(std::function<void(const std::string& ssid)> on_connected);
    void OnDisconnected(std::function<void(int reason)> on_disconnected);
    void OnScanBegin(std::function<void()> on_scan_begin);
    void SetScanIntervalRange(int min_interval_seconds, int max_interval_seconds);
    // Someone is using the device: if we are idle waiting out the backoff,
    // scan now and restart the backoff from the minimum. Throttled.
    void ScanNow();
    void SetHostname(const std::string& hostname) { hostname_ = hostname; }
    void SetPreferredSsid(std::function<std::string()> provider) { preferred_ssid_ = std::move(provider); }
    void SetNetworkAllowed(std::function<bool(const std::string&)> predicate) { network_allowed_ = std::move(predicate); }

    // How many times to retry the strongest same-SSID AP before falling back to
    // a weaker one. Only effective when remember_bssid is off (default). A value
    // of 3 means the driver will attempt the best AP up to 3 extra times before
    // giving up and trying the next-best BSSID.
    void SetFailureRetryCnt(uint8_t cnt) { failure_retry_cnt_ = cnt; }

private:
    EventGroupHandle_t event_group_;
    esp_timer_handle_t timer_handle_ = nullptr;
    esp_event_handler_instance_t instance_any_id_ = nullptr;
    esp_event_handler_instance_t instance_got_ip_ = nullptr;
    esp_netif_t* station_netif_ = nullptr;
    std::string ssid_;
    std::string password_;
    std::string ip_address_;
    std::string hostname_;
    int8_t max_tx_power_;
    uint8_t remember_bssid_;
    uint8_t failure_retry_cnt_ = 3;  // Retries on strongest AP before falling back
    int reconnect_count_ = 0;
    int64_t last_scan_now_us_ = 0;

    // Exponential backoff for scan interval
    int scan_min_interval_microseconds_ = 10 * 1000 * 1000;   // Default 10 seconds
    int scan_max_interval_microseconds_ = 300 * 1000 * 1000;  // Default 5 minutes
    int scan_current_interval_microseconds_ = 10 * 1000 * 1000;  // Current interval
    std::function<void(const std::string& ssid)> on_connect_;
    std::function<void(const std::string& ssid)> on_connected_;
    std::function<void(int reason)> on_disconnected_;
    std::function<void()> on_scan_begin_;
    std::vector<WifiApRecord> connect_queue_;
    std::function<std::string()> preferred_ssid_;
    std::function<bool(const std::string&)> network_allowed_;
    bool was_connected_ = false;  // Track if we were connected before disconnection

    void HandleScanResult();
    void StartScan();
    void ScheduleNextScan();
    void StartConnect();
    void UpdateScanInterval();  // Exponential backoff for scan interval
    static void WifiEventHandler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data);
    static void IpEventHandler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data);
};

#endif // _WIFI_STATION_H_
