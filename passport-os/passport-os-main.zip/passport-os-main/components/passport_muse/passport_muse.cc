// Passport OS adapter for Meta's community Muse Gadget SDK. No account secrets
// are compiled in. All chat-turn calls belong to this module's single worker.
#include "passport_muse.h"
extern "C" {
#include "config_store.h"
#include "ble_server.h"
#include "link_pairing.h"
#include "vm_api.h"
#include "muse_chat.h"
#include "muse_chat_priv.h"
#include "muse_link.h"
#include "muse_wifi.h"
#include "http_proxy.h"
#include "proxy_route.h"
}
#include "noise_control.h"
#include "wifi_manager.h"
#include "bsp_audio.h"
#include "bsp_memory.h"
#include "esp_app_desc.h"
#include "esp_mac.h"
#include "esp_wifi.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "lwip/netdb.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>

namespace {
portMUX_TYPE s_lock = portMUX_INITIALIZER_UNLOCKED;
passport_muse_snapshot_t s_view{};
std::atomic<bool> s_active{false}, s_exit{false}, s_pressed{false}, s_cancel{false};
std::atomic<bool> s_confirm{false}, s_pair_done{false}, s_refresh{false};
std::atomic<bool> s_connected_event{false};
std::atomic<bool> s_prepare_event{false};
std::atomic<const char *> s_connect_detail{"正在重新连接"};
std::atomic<bool> s_repair{false};
std::atomic<bool> s_paired{false};
std::atomic<uint32_t> s_pairing_prompt_generation{0};
std::atomic<unsigned> s_callbacks{0};
std::atomic<bool> s_worker_running{false};
// Set when the last connect failed for a network reason the worker may retry
// on its own (Wi-Fi down, DNS, proxy or cloud unreachable).
bool s_retryable;
char s_sdk_token[64], s_node[64], s_mac[18], s_device_id[64], s_ble_name[32];

void view(passport_muse_stage_t stage, const char *detail) {
    portENTER_CRITICAL(&s_lock);
    s_view.stage = stage;
    strlcpy(s_view.detail, detail, sizeof(s_view.detail));
    portEXIT_CRITICAL(&s_lock);
}
const char *voice_error_detail(const char *reason) {
    if (strstr(reason, "NOT READY")) return "Muse 还未就绪，请稍后重试";
    if (strstr(reason, "QUEUE BUSY")) return "语音发送繁忙，请稍后重试";
    if (strstr(reason, "SERVER ERROR")) return "Muse 服务异常，请稍后重试";
    if (strstr(reason, "REQUEST ERROR")) return "Muse 未接受请求，按确定键重连";
    if (strstr(reason, "INVALID RESPONSE")) return "Muse 回复解析失败，请重试";
    if (strstr(reason, "PROTOCOL ERROR")) return "Muse 数据处理失败，请重连";
    if (strstr(reason, "REPLY OUT OF MEMORY")) return "接收内存不足，请返回重试";
    if (strstr(reason, "OUT OF MEMORY")) return "录音内存不足，松开上键后重试";
    if (strstr(reason, "CAN'T KEEP UP")) return "语音上传中断，检查网络后重试";
    if (strstr(reason, "SYNC INTERRUPTED")) return "回复同步中断，按确定键重连";
    if (strstr(reason, "NO REPLY")) return "回复超时，可在手机 Muse 查看";
    if (strstr(reason, "REPLY EVENT TOO LARGE")) return "回复数据过大，请在手机查看";
    if (strstr(reason, "BUFFER LIMIT")) return "回复缓存已满，请在手机查看";
    if (strstr(reason, "REPLY TOO LONG")) return "回复较长，请在手机 Muse 查看";
    if (strstr(reason, "AUTH") || strstr(reason, "DENIED")) return "Muse 授权异常，按确定键重连";
    return "Muse 连接中断，检查网络后重试";
}
void pairing_view(passport_muse_stage_t stage, const char *detail, uint32_t generation) {
    portENTER_CRITICAL(&s_lock);
    s_pairing_prompt_generation = generation;
    s_view.stage = stage;
    strlcpy(s_view.detail, detail, sizeof(s_view.detail));
    portEXIT_CRITICAL(&s_lock);
}
void recover_pairing_prompt(uint32_t generation) {
    portENTER_CRITICAL(&s_lock);
    if (s_pairing_prompt_generation == generation &&
        (s_view.stage == PASSPORT_MUSE_CONFIRM || s_view.stage == PASSPORT_MUSE_PHONE_SETUP)) {
        s_pairing_prompt_generation = 0;
        s_view.stage = PASSPORT_MUSE_PAIRING;
        strlcpy(s_view.detail, "手机 Muse / 设置 / 设备", sizeof(s_view.detail));
    }
    portEXIT_CRITICAL(&s_lock);
}
void answer(const char *text) {
    portENTER_CRITICAL(&s_lock);
    if (text[0] && s_view.reply_is_answer) { portEXIT_CRITICAL(&s_lock); return; }
    // SDK emits valid UTF-8 captions; do not clip halfway through a character.
    muse_hatch_tail_words(text, s_view.reply, sizeof(s_view.reply));
    s_view.reply_revision++;
    s_view.reply_is_answer = false;
    portEXIT_CRITICAL(&s_lock);
}
void reply_answer() {
    portENTER_CRITICAL(&s_lock);
    if (muse_hatch_turn_reply(s_view.reply, sizeof(s_view.reply))) {
        s_view.reply_revision++; s_view.reply_is_answer = true;
    }
    portEXIT_CRITICAL(&s_lock);
}
void status(const char *state) {
    if (s_exit) return;
    if (!strcmp(state, "ws_prepare")) s_prepare_event = true;
    else if (!strcmp(state, "ws_connected")) {
        s_connect_detail = "正在重新连接";
        s_connected_event = true;
    }
    else if (!strcmp(state, "ws_auth_failed") || !strcmp(state, "ws_refresh_needed")) s_refresh = true;
    else if (!strcmp(state, "ws_disconnected")) {
        s_connected_event = false;
        view(PASSPORT_MUSE_CONNECTING, s_connect_detail.load());
    }
    else if (!strcmp(state, "ws_registration_failed") || !strcmp(state, "ws_registration_timeout")) {
        s_connect_detail = "Muse 注册失败，正在重连";
        view(PASSPORT_MUSE_CONNECTING, s_connect_detail.load());
    }
    else if (!strcmp(state, "ws_tls_failed")) {
        s_connect_detail = "安全连接失败，正在重连";
        view(PASSPORT_MUSE_CONNECTING, s_connect_detail.load());
    }
    else if (!strcmp(state, "ws_server_failed")) {
        s_connect_detail = "Muse 服务异常，正在重连";
        view(PASSPORT_MUSE_CONNECTING, s_connect_detail.load());
    }
    else if (!strcmp(state, "ws_memory_failed")) {
        s_connect_detail = "内存不足，正在重连";
        view(PASSPORT_MUSE_CONNECTING, s_connect_detail.load());
    }
    else if (!strcmp(state, "ws_unpaired")) {
        config_clear_pairing();
        s_paired = false;
        s_exit = true;
        view(PASSPORT_MUSE_ERROR, "请在 Muse 中重新配对");
    }
}
void agent_name(const char *name) {
    portENTER_CRITICAL(&s_lock);
    muse_hatch_tail_words(name, s_view.name, sizeof(s_view.name));
    portEXIT_CRITICAL(&s_lock);
}
cJSON *command(const char *, cJSON *, const char *, noise_ctrl_session_generation_t) {
    cJSON *out = cJSON_CreateObject();
    if (out) cJSON_AddStringToObject(out, "error", "Passport OS does not execute remote device commands");
    return out;
}
void send_json(cJSON *obj, uint32_t generation) {
    char *json = cJSON_PrintUnformatted(obj);
    cJSON_Delete(obj);
    if (json) { ble_server_send_encrypted_json(json, generation); free(json); }
}
void scan() {
    // This application reuses Passport OS Wi-Fi rather than changing the whole
    // system's connection from a second radio manager. Expose its real network.
    auto &wifi = WifiManager::GetInstance();
    cJSON *obj = cJSON_CreateObject(), *arr = cJSON_CreateArray();
    if (!obj || !arr) { cJSON_Delete(obj); cJSON_Delete(arr); return; }
    cJSON_AddStringToObject(obj, "type", "wifi_scan_result");
    if (wifi.IsConnected()) {
        cJSON *item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "ssid", wifi.GetSsid().c_str());
        cJSON_AddNumberToObject(item, "rssi", wifi.GetRssi());
        wifi_ap_record_t ap{};
        bool secure = esp_wifi_sta_get_ap_info(&ap) == ESP_OK && ap.authmode != WIFI_AUTH_OPEN;
        cJSON_AddBoolToObject(item, "secure", secure);
        cJSON_AddItemToArray(arr, item);
    }
    cJSON_AddItemToObject(obj, "networks", arr);
    send_json(obj, link_pairing_session_generation());
}
void device_info() {
    cJSON *obj = cJSON_CreateObject();
    if (!obj) return;
    cJSON_AddStringToObject(obj, "type", "device_info");
    cJSON_AddStringToObject(obj, "node_id", s_node);
    cJSON_AddStringToObject(obj, "version", esp_app_get_description()->version);
    link_pairing_add_device_info(obj);
    // Muse asks for these public protocol capabilities BEFORE client_hello.
    // There is no encrypted session yet: using send_json() drops generation 0
    // and makes the phone time out without ever reaching physical confirmation.
    // Match the upstream discovery response; secrets/provisioning stay encrypted.
    char *json = cJSON_PrintUnformatted(obj);
    cJSON_Delete(obj);
    if (json) { ble_server_send_chunked(json); free(json); }
}
void finished(uint32_t generation) {
    if (s_exit || !link_pairing_session_is_current(generation)) return;
    if (ble_server_send_pairing_status("confirm_required", generation) &&
        link_pairing_arm_confirmation(generation)) pairing_view(PASSPORT_MUSE_CONFIRM, "按确定键允许配对", generation);
    else ble_server_disconnect_pairing_session(generation);
}
void provision(const char *ssid, const char *, const char *access, const char *refresh,
               const char *username, const char *, bool, const char *,
               const char *api, const char *host, uint32_t generation) {
    s_callbacks++;
    if (!s_exit && link_pairing_provisioning_session_valid(generation)) {
        pairing_view(PASSPORT_MUSE_PHONE_SETUP, "正在保存手机配置", generation);
        auto &wifi = WifiManager::GetInstance();
        if (!ssid || !*ssid || !access || !*access || !refresh || !*refresh) {
            ble_server_send_pairing_status("error_missing_credentials", generation);
            view(PASSPORT_MUSE_ERROR, "配对资料不完整，请在手机重试");
        } else if (!wifi.IsConnected() || wifi.GetSsid() != ssid) {
            ble_server_send_pairing_status("wifi_failed", generation);
            view(PASSPORT_MUSE_ERROR, "手机配对时\n请选择设备当前 Wi-Fi");
        } else {
            ble_server_send_pairing_status("wifi_connected", generation);
            bool ok = config_clear_setup_complete() && config_set_str("access_token", access) &&
                config_set_str("refresh_token", refresh) && config_set_str("username", username ? username : "") &&
                config_set_str("api_url_v2", api ? api : "") && config_set_str("noise_host", host ? host : "");
            // Pairing records are encrypted and physically confirmed. Commit
            // only if this exact session is still valid after the NVS writes.
            ok = ok && !s_exit && link_pairing_commit_provisioning(generation, config_mark_setup_complete);
            if (ok) {
                if (ble_server_send_pairing_status("auth_ok", generation)) {
                    s_paired = true;
                    s_pair_done = true;
                } else {
                    // Keep discovery alive when the final result was not sent.
                    config_clear_setup_complete();
                    view(PASSPORT_MUSE_ERROR, "配对结果未送达，请重新添加");
                }
            } else {
                config_clear_pairing();
                ble_server_send_pairing_status("error_storage", generation);
                view(PASSPORT_MUSE_ERROR, "配对未保存，请重试");
            }
        }
    }
    s_callbacks--;
}
void unpair() {
    // Defer storage/connection mutation to the owner task.
    s_cancel = true;
    config_clear_pairing();
    s_paired = false;
    s_exit = true;
    view(PASSPORT_MUSE_ERROR, "已解除配对，重新进入可配对");
}
void setup_ble() {
    const ble_callbacks_t callbacks = {
        .on_provision = provision, .on_wifi_scan = scan, .on_ota = nullptr,
        .on_unpair = unpair, .on_get_device_info = device_info,
        .on_client_connected = nullptr, .on_client_disconnected = nullptr,
        .on_pairing_client_finished = finished,
    };
    link_pairing_init(s_node, s_device_id, s_mac, esp_app_get_description()->version, s_sdk_token);
    ble_server_start(s_ble_name, &callbacks);
    if (ble_server_is_started()) {
        ble_server_begin_advertising();
        view(PASSPORT_MUSE_PAIRING, "手机 Muse / 设置 / 设备");
    } else view(PASSPORT_MUSE_ERROR, "蓝牙启动失败，请返回重试");
}
void log_network() {
    esp_netif_t *netif = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    passport_muse_snapshot_t current; passport_muse_snapshot(&current);
    ESP_LOGI("muse_net", "stage=%d reply_bytes=%u revision=%u cloud=%d", (int)current.stage,
             (unsigned)strlen(current.reply), (unsigned)current.reply_revision, noise_ctrl_is_connected());
    ESP_LOGI("muse_net", "wifi=%d paired=%d worker=%d ble=%d heap=%u largest=%u",
        muse_wifi_connected(), s_paired.load(), s_worker_running.load(), ble_server_is_started(),
        (unsigned)esp_get_free_heap_size(),
        (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT));
    for (int i = ESP_NETIF_DNS_MAIN; netif && i <= ESP_NETIF_DNS_FALLBACK; ++i) {
        esp_netif_dns_info_t dns{};
        if (esp_netif_get_dns_info(netif, static_cast<esp_netif_dns_type_t>(i), &dns) == ESP_OK
            && dns.ip.type == ESP_IPADDR_TYPE_V4) {
            char address[16]; esp_ip4addr_ntoa(&dns.ip.u_addr.ip4, address, sizeof(address));
            // DNS addresses only; never log Wi-Fi passwords or account tokens.
            ESP_LOGI("muse_net", "dns%d=%s", i, address);
        }
    }
}
bool resolve_api(const char *endpoint) {
    const char *url = endpoint && *endpoint ? endpoint : VM_API_DEFAULT_BASE_URL;
    const char *begin = strstr(url, "://");
    if (!begin) { view(PASSPORT_MUSE_ERROR, "服务器配置无效，请重新配对"); return false; }
    begin += 3;
    size_t length = strcspn(begin, ":/?#");
    char hostname[128];
    if (!length || length >= sizeof(hostname)) {
        view(PASSPORT_MUSE_ERROR, "服务器配置无效，请重新配对"); return false;
    }
    memcpy(hostname, begin, length); hostname[length] = 0;
    log_network();
    struct addrinfo hints{}, *result = nullptr;
    hints.ai_family = AF_INET; hints.ai_socktype = SOCK_STREAM;
    int rc = getaddrinfo(hostname, nullptr, &hints, &result);
    if (result) freeaddrinfo(result);
    ESP_LOGI("muse_net", "api_dns_result=%d", rc);
    if (rc) { view(PASSPORT_MUSE_ERROR, "服务器域名解析失败\n网络恢复后自动重连"); s_retryable = true; }
    return rc == 0;
}
bool connect_account(bool refresh_first) {
    if (ble_server_is_started()) {
        view(PASSPORT_MUSE_ERROR, "蓝牙未释放，请重启后连接");
        return false;
    }
    s_retryable = false;
    view(PASSPORT_MUSE_CONNECTING, "正在连接你的 Muse");
    if (!muse_wifi_connected()) {
        view(PASSPORT_MUSE_ERROR, "Wi-Fi 未连接\n连上网络后自动重连"); s_retryable = true; return false;
    }
    char endpoint[256], host[128];
    config_get_str("api_url_v2", endpoint, sizeof(endpoint));
    config_get_str("noise_host", host, sizeof(host));
    muse_proxy_load_config();
    // Fail at the actual DNS boundary before allocating credential/TLS buffers.
    if ((!muse_proxy_enabled() && !resolve_api(endpoint)) || s_exit) return false;
    if (muse_proxy_enabled()) log_network();
    char *access = static_cast<char *>(calloc(1, 4096));
    char *refresh = static_cast<char *>(calloc(1, 4096));
    if (!access || !refresh) {
        free(access); free(refresh);
        view(PASSPORT_MUSE_ERROR, "内存不足，请返回重试"); return false;
    }
    config_get_str("access_token", access, 4096);
    config_get_str("refresh_token", refresh, 4096);
    vm_api_set_base_url(endpoint);
    vm_api_set_sdk_token(s_sdk_token);
    noise_ctrl_set_host(host);
    vm_info_t vms[VM_API_MAX_VMS] = {};
    bool refresh_rejected = false, storage_failed = false;
    int count = refresh_first ? VM_API_ERR_AUTH : vm_api_fetch_vms(access, vms, VM_API_MAX_VMS);
    if (!s_exit && count == VM_API_ERR_AUTH) {
        vm_device_tokens_t tokens{};
        // The SDK's token endpoint calls this field device_id, but upstream
        // supplies the advertised node_id, not the pairing transcript device_id.
        int refreshed = vm_api_refresh_device_token(nullptr, refresh, s_node, &tokens, nullptr);
        refresh_rejected = refreshed == VM_API_ERR_AUTH;
        if (refreshed == 0) {
            if (config_set_str("access_token", tokens.access_token) && config_set_str("refresh_token", tokens.refresh_token)) {
                strlcpy(access, tokens.access_token, 4096);
                count = s_exit ? 0 : vm_api_fetch_vms(access, vms, VM_API_MAX_VMS);
            } else { storage_failed = true; count = VM_API_ERR_FAILED; }
        } else count = refreshed;
        vm_device_tokens_free(&tokens);
    }
    free(access); free(refresh);
    const vm_info_t *vm = count > 0 ? vm_find_default(vms, count) : nullptr;
    bool ok = !s_exit && vm && noise_ctrl_connect(vm->vm_id, vm->vm_auth_token, WifiManager::GetInstance().GetSsid().c_str());
    vm_list_free(vms, count > 0 ? count : 0);
    s_retryable = !ok && !storage_failed && !refresh_rejected && count != VM_API_ERR_AUTH && count != 0;
    if (!ok && !s_exit) view(PASSPORT_MUSE_ERROR, storage_failed ? "授权未保存，请确定重试" :
        refresh_rejected ? "账号授权失效，请重新配对" :
        count == VM_API_ERR_AUTH ? "云端暂未接受授权\n确定重试" :
        count == 0 ? "账号没有可用的 Muse，请查看手机" : "云端未连通\n稍后自动重连");
    return ok;
}
// Full teardown and fresh account connect; also re-reads the proxy route.
void reconnect() {
    muse_hatch_turn_cancel();
    noise_ctrl_disconnect();
    muse_hatch_stop();
    if (!s_exit) connect_account(false);
}
void worker(void *) {
    bool recording = false, previous_press = false, capture_wifi = false;
    int64_t began = 0;
    // Recover from network errors without a key press while Wi-Fi comes back.
    bool was_online = true;
    int64_t net_check_at = 0, retry_at = 0, retry_delay = 10000000;
    if (!s_paired) setup_ble();
    else connect_account(false);
    while (!s_exit) {
        if (s_prepare_event.exchange(false)) {
            if (recording) { recording = false; bsp_audio_deinit(); }
            s_pressed = false; previous_press = false;
            muse_hatch_suspend();
            bsp_memory_phase("muse.tls");
            noise_ctrl_prepared();
        }
        if (!s_paired && !s_callbacks && ble_server_is_started()) {
            passport_muse_snapshot_t current; passport_muse_snapshot(&current);
            if (current.stage == PASSPORT_MUSE_CONFIRM || current.stage == PASSPORT_MUSE_PHONE_SETUP) {
                uint32_t generation = s_pairing_prompt_generation.load();
                if (!link_pairing_confirmation_required() && !link_pairing_session_confirmed()) {
                    // Keep the prompt's token: expiry can make the public
                    // active-session getter return zero. A new hello has its
                    // own generation and must never be closed by this prompt.
                    if (link_pairing_session_is_current(generation))
                        ble_server_disconnect_pairing_session(generation);
                    recover_pairing_prompt(generation);
                }
            } else if (current.stage == PASSPORT_MUSE_ERROR && !ble_server_has_connection()) {
                view(PASSPORT_MUSE_PAIRING, "手机 Muse / 设置 / 设备");
            }
        }
        if (s_repair.exchange(false)) {
            s_pressed = false; previous_press = false;
            muse_hatch_turn_cancel();
            if (recording) { recording = false; bsp_audio_deinit(); }
            noise_ctrl_disconnect();
            while (s_callbacks && !s_exit) vTaskDelay(pdMS_TO_TICKS(10));
            ble_server_full_shutdown(); link_pairing_reset();
            muse_hatch_stop();
            if (!s_exit && config_clear_pairing()) {
                s_paired = false; s_pair_done = false; s_refresh = false; s_confirm = false;
                portENTER_CRITICAL(&s_lock); s_view.paired = false; portEXIT_CRITICAL(&s_lock);
                setup_ble();
            } else if (!s_exit) view(PASSPORT_MUSE_ERROR, "配对记录未清除，请返回重试");
        }
        if (s_confirm.exchange(false)) {
            passport_muse_snapshot_t current; passport_muse_snapshot(&current);
            uint32_t gen = link_pairing_confirm_active_session();
            if (gen) {
                if (ble_server_send_pairing_status("pairing_confirmed", gen))
                    pairing_view(PASSPORT_MUSE_PHONE_SETUP, "请在手机选择当前 Wi-Fi", gen);
                else {
                    ble_server_disconnect_pairing_session(gen);
                    view(PASSPORT_MUSE_ERROR, "确认未送达，请在手机重试");
                }
            }
            else if (s_paired && !recording && current.stage == PASSPORT_MUSE_ERROR) {
                reconnect();
                retry_delay = 10000000; retry_at = esp_timer_get_time() + retry_delay;
            }
        }
        if (s_pair_done.exchange(false)) {
            while (s_callbacks && !s_exit) vTaskDelay(pdMS_TO_TICKS(10));
            // Upstream keeps the GATT connection alive for 2 seconds after
            // auth_ok. Immediate teardown loses the phone's final setup result.
            int64_t deadline = esp_timer_get_time() + 2000000;
            while (!s_exit && esp_timer_get_time() < deadline) vTaskDelay(pdMS_TO_TICKS(20));
            ble_server_full_shutdown();
            portENTER_CRITICAL(&s_lock); s_view.paired = true; portEXIT_CRITICAL(&s_lock);
            if (!s_exit) connect_account(false);
        }
        // Refresh only after a real server refusal/request. The SDK's device
        // access tokens are long-lived; timer rotation can replace a valid pair.
        if (!recording && s_paired && s_refresh.exchange(false)) {
            muse_hatch_turn_cancel();
            noise_ctrl_disconnect();
            muse_hatch_stop();
            if (!s_exit) connect_account(true);
        }
        // Keep chat scratch out of both BLE setup and the TLS handshake peak.
        // Only the owner allocates it, after the cloud task reports readiness.
        if (s_connected_event.exchange(false) && !s_exit && noise_ctrl_is_connected()) {
            bsp_memory_phase("muse.ready");
            muse_hatch_start();
            if (!muse_hatch_initialized()) {
                muse_hatch_stop();
                noise_ctrl_disconnect();
                view(PASSPORT_MUSE_ERROR, "内存不足，请返回重试");
            } else {
                passport_muse_snapshot_t current; passport_muse_snapshot(&current);
                if (current.reply_is_answer) view(PASSPORT_MUSE_REPLY, "继续同步后续回复");
                else view(PASSPORT_MUSE_READY, "按住上键说话");
            }
        }
        int64_t now = esp_timer_get_time();
        if (!recording && s_paired && !s_exit && now >= net_check_at) {
            net_check_at = now + 1000000;
            bool online = muse_wifi_connected();
            passport_muse_snapshot_t current; passport_muse_snapshot(&current);
            if (current.stage == PASSPORT_MUSE_ERROR) {
                // Wi-Fi coming back retries at once; otherwise back off 10 s -> 60 s.
                if (s_retryable && online && (!was_online || now >= retry_at)) {
                    ESP_LOGI("muse_net", "auto reconnect after network error");
                    reconnect();
                    retry_at = esp_timer_get_time() + retry_delay;
                    if (retry_delay < 60000000) retry_delay *= 2;
                }
            }
            was_online = online;
            if (current.stage == PASSPORT_MUSE_READY) retry_delay = 10000000;
        }
        bool pressed = s_pressed;
        if (s_cancel.exchange(false)) {
            pressed = false; s_pressed = false;
            muse_hatch_turn_cancel();
            if (recording) { recording = false; bsp_audio_deinit(); }
            view(noise_ctrl_is_connected() ? PASSPORT_MUSE_READY : PASSPORT_MUSE_CONNECTING, "已停止等待，已发送任务请在手机查看");
        }
        if (pressed && !previous_press) {
            if (muse_hatch_ready()) {
                bsp_memory_phase("muse.record");
                WifiManager::GetInstance().SetPowerSaveLevel(WifiPowerSaveLevel::PERFORMANCE);
                capture_wifi = true;
            }
            if (muse_hatch_ready() && bsp_audio_init_capture() == ESP_OK && bsp_audio_set_format(16000, 16, 1) == ESP_OK) {
                muse_hatch_turn_begin();
                recording = muse_hatch_turn_recording();
                if (recording) {
                    began = esp_timer_get_time();
                    answer(""); view(PASSPORT_MUSE_LISTENING, "松开上键发送");
                    ESP_LOGI("muse_ptt", "recording started heap=%u largest=%u",
                             (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
                             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
                } else bsp_audio_deinit();
            } else { bsp_audio_deinit(); view(PASSPORT_MUSE_ERROR, "连接或麦克风未就绪"); }
        }
        if (recording && (!pressed || esp_timer_get_time() - began >= 30000000)) {
            recording = false; s_pressed = false; pressed = false;
            ESP_LOGI("muse_ptt", "recording stopped duration_ms=%lld", (long long)((esp_timer_get_time() - began) / 1000));
            bsp_audio_deinit();
            bsp_memory_phase("muse.reply");
            muse_hatch_turn_end();
            view(PASSPORT_MUSE_WORKING, "等待 Muse 回复");
        }
        previous_press = pressed;
        if (recording) {
            int16_t pcm[256];
            if (bsp_audio_read(pcm, sizeof(pcm)) != ESP_OK) {
                muse_hatch_turn_cancel(); bsp_audio_deinit(); recording = false;
                view(PASSPORT_MUSE_ERROR, "录音失败，请重试");
            } else {
                unsigned peak = 0;
                for (int16_t sample : pcm) { unsigned n = sample < 0 ? -int(sample) : sample; if (n > peak) peak = n; }
                portENTER_CRITICAL(&s_lock); s_view.level = peak; portEXIT_CRITICAL(&s_lock);
                muse_hatch_turn_audio(pcm, 256);
            }
        }
        char text[160];
        muse_hatch_ev_t ev = muse_hatch_turn_event(text, sizeof(text));
        if (ev == MUSE_HATCH_EV_ERROR) {
            bsp_memory_dump();
            if (recording) bsp_audio_deinit();
            recording = false; s_pressed = false; previous_press = false;
            view(PASSPORT_MUSE_ERROR, voice_error_detail(text));
        } else if (ev == MUSE_HATCH_EV_HEARD) {
            answer(text);
        } else if (ev == MUSE_HATCH_EV_REPLY) {
            reply_answer(); view(PASSPORT_MUSE_REPLY, "继续同步后续回复");
        } else if (ev == MUSE_HATCH_EV_SYNCING) {
            view(PASSPORT_MUSE_WORKING, "正在恢复回复同步");
        } else if (ev == MUSE_HATCH_EV_RESUMED || ev == MUSE_HATCH_EV_DONE) {
            passport_muse_snapshot_t current; passport_muse_snapshot(&current);
            view(current.reply_is_answer ? PASSPORT_MUSE_REPLY : PASSPORT_MUSE_WORKING, "继续同步后续回复");
        } else if (ev == MUSE_HATCH_EV_SENT) {
            view(PASSPORT_MUSE_WORKING, "Muse 已收到语音");
        }
        if (!recording && capture_wifi) {
            WifiManager::GetInstance().SetPowerSaveLevel(WifiPowerSaveLevel::BALANCED);
            capture_wifi = false;
        }
        if (!recording) vTaskDelay(pdMS_TO_TICKS(30));
    }
    muse_hatch_turn_cancel();
    if (recording) bsp_audio_deinit();
    if (capture_wifi) WifiManager::GetInstance().SetPowerSaveLevel(WifiPowerSaveLevel::BALANCED);
    noise_ctrl_disconnect();
    while (s_callbacks) vTaskDelay(pdMS_TO_TICKS(10));
    ble_server_full_shutdown();
    link_pairing_reset();
    s_worker_running = false;
    vTaskDelete(nullptr);
}
} // namespace

extern "C" bool muse_wifi_connected(void) { return WifiManager::GetInstance().IsConnected(); }
extern "C" bool muse_link_hatch_linked(void) { return s_paired; }
extern "C" bool muse_link_req_ready(void) { return noise_ctrl_is_connected(); }
extern "C" int64_t muse_link_req_open(const char *v, const char *p, const char *const *h, bool e, muse_link_req_cb cb, void *ctx) {
    return noise_ctrl_req_open(v, p, h, e, cb, ctx);
}
extern "C" bool muse_link_req_send(int64_t id, const void *p, size_t n, bool end, int ms) { return noise_ctrl_req_send(id, p, n, end, ms); }
extern "C" const char *muse_link_req_error(void) { return noise_ctrl_req_error(); }
extern "C" void muse_link_req_cancel(int64_t id) { noise_ctrl_req_cancel(id); }

extern "C" esp_err_t passport_muse_set_sdk_token(const char *token) {
    if (s_active.exchange(true)) return ESP_ERR_INVALID_STATE;
    struct ReleaseConfigGate { ~ReleaseConfigGate() { s_active = false; } } release;
    if (!token || strncmp(token, "mgst_", 5) || strlen(token) < 12 || strlen(token) >= sizeof(s_sdk_token)) return ESP_ERR_INVALID_ARG;
    for (const char *p = token; *p; ++p) if (*p <= 32 || *p >= 127) return ESP_ERR_INVALID_ARG;
    char old[64];
    config_get_str("sdk_token", old, sizeof(old));
    if (strcmp(old, token) && !config_clear_pairing()) return ESP_FAIL;
    return config_set_str("sdk_token", token) ? ESP_OK : ESP_FAIL;
}
extern "C" void passport_muse_config_status(bool *token, bool *paired) {
    char value[64];
    if (token) *token = config_get_str("sdk_token", value, sizeof(value)) && value[0];
    if (paired) *paired = config_is_provisioned();
}
extern "C" esp_err_t passport_muse_set_proxy(const char *host, uint16_t port) {
    if (s_active.exchange(true)) return ESP_ERR_INVALID_STATE;
    struct ReleaseConfigGate { ~ReleaseConfigGate() { s_active = false; } } release;
    if (!muse_proxy_valid_config(host, port)) return ESP_ERR_INVALID_ARG;
    return muse_proxy_save_config(host, port) ? ESP_OK : ESP_FAIL;
}
extern "C" bool passport_muse_proxy_valid(const char *host, uint16_t port) { return muse_proxy_valid_config(host, port); }
extern "C" int passport_muse_proxy_route_info(char *host, size_t cap, uint16_t *port) { return muse_proxy_route_info(host, cap, port); }
extern "C" void passport_muse_proxy_config(char *host, size_t cap, uint16_t *port) {
    muse_proxy_get_config(host, cap, port);
}
extern "C" esp_err_t passport_muse_start(void) {
    if (s_active.exchange(true)) return ESP_ERR_INVALID_STATE;
    s_exit = false; s_pressed = false; s_cancel = false; s_confirm = false; s_pair_done = false; s_refresh = false; s_repair = false;
    s_connected_event = false;
    s_prepare_event = false;
    s_connect_detail = "正在重新连接";
    s_pairing_prompt_generation = 0;
    bool token, paired; passport_muse_config_status(&token, &paired);
    s_paired = paired;
    uint8_t mac[6]; esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(s_mac, sizeof(s_mac), "%02x:%02x:%02x:%02x:%02x:%02x", mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    snprintf(s_node, sizeof(s_node), "homelink-%02x%02x%02x", mac[3],mac[4],mac[5]);
    snprintf(s_device_id, sizeof(s_device_id), "hatch-link:%s", s_mac);
    snprintf(s_ble_name, sizeof(s_ble_name), "MuseGadget-%02X%02X%02X", mac[3],mac[4],mac[5]);
    portENTER_CRITICAL(&s_lock);
    s_view = {}; s_view.sdk_token_set = token; s_view.paired = paired;
    strlcpy(s_view.name, "Muse", sizeof(s_view.name)); strlcpy(s_view.device_name, s_ble_name, sizeof(s_view.device_name));
    portEXIT_CRITICAL(&s_lock);
    if (!token) { view(PASSPORT_MUSE_NEEDS_TOKEN, "手机设置页填写 SDK Token"); return ESP_OK; }
    // A paired device waits in the worker and reconnects once Wi-Fi is up;
    // pairing itself needs the network the phone will choose.
    if (!paired && !muse_wifi_connected()) { view(PASSPORT_MUSE_ERROR, "请先连接 Wi-Fi"); return ESP_OK; }
    config_get_str("sdk_token", s_sdk_token, sizeof(s_sdk_token));
    if (!noise_ctrl_initialized()) {
        noise_ctrl_init(s_node, "Passport OS", status);
        noise_ctrl_set_agent_name_cb(agent_name); noise_ctrl_set_command_cb(command);
    }
    if (!noise_ctrl_initialized()) { view(PASSPORT_MUSE_ERROR, "内存不足，请返回重试"); return ESP_ERR_NO_MEM; }
    TaskHandle_t task = nullptr;
    view(PASSPORT_MUSE_CONNECTING, "正在准备连接");
    s_worker_running = true;
    // Proxy TLS plus the account-response parser exceeds 8 KiB on ESP-IDF
    // 5.5.3 (observed stack-protection fault just below the task boundary).
    // Keep this extra budget local to Muse instead of enlarging other apps.
    if (xTaskCreate(worker, "passport_muse", 12288, nullptr, 4, &task) != pdPASS) {
        s_worker_running = false;
        view(PASSPORT_MUSE_ERROR, "内存不足，请返回重试"); return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}
extern "C" bool passport_muse_stop(void) {
    s_exit = true;
    muse_proxy_cancel();
    // The owner exits cooperatively; never kill a task holding codec/TLS locks.
    while (s_worker_running.load()) vTaskDelay(pdMS_TO_TICKS(10));
    // worker() has disconnected and joined Home Link, so callbacks can no
    // longer reference the per-session chat scratch area.
    muse_hatch_stop();
    noise_ctrl_forget_session();
    s_active = false;
    return !ble_server_is_started();
}
extern "C" void passport_muse_key(bool pressed, bool cancel) { s_pressed = pressed; if (cancel) s_cancel = true; }
extern "C" void passport_muse_confirm(void) {
    if (s_active && !s_worker_running) { passport_muse_stop(); passport_muse_start(); }
    else s_confirm = true;
}
extern "C" void passport_muse_repair(void) {
    passport_muse_snapshot_t state; passport_muse_snapshot(&state);
    if (!s_active || (state.stage != PASSPORT_MUSE_ERROR && state.stage != PASSPORT_MUSE_PAIRING)) return;
    if (s_worker_running) s_repair = true;
    else {
        passport_muse_stop();
        if (config_clear_pairing()) passport_muse_start();
        else view(PASSPORT_MUSE_ERROR, "配对记录未清除，请返回重试");
    }
}
extern "C" void passport_muse_log_diagnostics(void) { log_network(); }
extern "C" void passport_muse_snapshot(passport_muse_snapshot_t *out) {
    if (!out) return;
    portENTER_CRITICAL(&s_lock); *out = s_view; portEXIT_CRITICAL(&s_lock);
}
extern "C" bool passport_muse_diagnostic_ble_cycle(void) {
    passport_muse_snapshot_t state; passport_muse_snapshot(&state);
    if (!s_active || s_worker_running || state.sdk_token_set || state.stage != PASSPORT_MUSE_NEEDS_TOKEN) return false;
    unsigned before = esp_get_free_heap_size();
    link_pairing_init(s_node, s_device_id, s_mac, esp_app_get_description()->version, nullptr);
    ble_server_start(s_ble_name, nullptr);
    vTaskDelay(pdMS_TO_TICKS(300));
    bool started = ble_server_is_started();
    unsigned during = esp_get_free_heap_size();
    ble_server_full_shutdown(); link_pairing_reset();
    vTaskDelay(pdMS_TO_TICKS(100));
    bool stopped = !ble_server_is_started();
    ESP_LOGI("muse_probe", "BLE cycle: started=%d stopped=%d before=%u during=%u after=%u", started, stopped, before, during, (unsigned)esp_get_free_heap_size());
    return started && stopped;
}
