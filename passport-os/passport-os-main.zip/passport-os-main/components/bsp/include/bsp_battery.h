// components/bsp/include/bsp_battery.h
// CellWise CW2017 电量计:I2C 0x63,与 ES8311 共用总线。
// BSP 写入本机优特利 520mAh 电芯的厂家 profile，芯片直接给出 SOC%。
#pragma once

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// 初始化。内部会调 bsp_i2c_init()(幂等)。
// 芯片不应答时返回 ESP_ERR_NOT_FOUND —— 上层可据此在 UI 上标记该项不可用。
esp_err_t bsp_battery_init(void);

// Cached gauge readings, refreshed every 10s by the system monitor. Invalid or
// contradictory readings return -1; voltage is never converted into a fake SOC.
int bsp_battery_soc(void);
void bsp_battery_poll(void);
void bsp_battery_log_status(void);

// 电池电压 mV;读失败返回 -1。
int bsp_battery_mv(void);

#ifdef __cplusplus
}
#endif
